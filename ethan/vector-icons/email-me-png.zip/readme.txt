email me by Mayosoft

All content in this zip file, included icons & preview are copyrighted by me. They are for personal use only.
You may not publish on any website or place for download these icons anywhere without my permission. 
You may not sell or use them for profit in any way. 
Do not take credit of the creation of of these icons.
It's completely prohibited alter, divide, or separate any part of the content of the original package, (Available at DeviantART)
If you have any question about this or any of my creations please e-mail me mayosoft@gmail.com

Enjoy it!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Todo el contenido del archivo zip, incluidos los iconos y la portada poseen derechos reservados. Solo para uso personal.
No publicar en ningun sitio web o ponerlos a disposicion para descargar sin mi permiso previo.
No venderlos o lucrar con ellos de ninguna manera.
No adjudicarse el credito de la creacion de estos iconos.
Queda totalmente prohibido alterar, dividir, o separar cualquier parte del contenido del paquete original, (disponible en DeviantART)
Si tienes alguna pregunta acerca de mis creaciones enviame un e-mail a mayosoft@gmail.com

Disfrutenlos!!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Tama�o PNG / PNG Size: 128x128 pixels

Tama�o ICO / ICO Size: 128X128 pixels

11 icons included

http://www.mayosoft.net
http://mayosoft.deviantart.com
..::Mayosoft::..